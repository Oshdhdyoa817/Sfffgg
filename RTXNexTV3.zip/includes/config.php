<?php
//name of panel
$panel_name = "HC All in One";

// show Time of Arrival on login page
// yes or no
$show_toa = "yes";

// show IP address on login page
// yes or no
$show_ip = "yes";

